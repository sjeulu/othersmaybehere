#version 330

uniform sampler2D DiffuseSampler;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

const float blurSize = 0.25; // Adjust this value to control the strength of the blur
const float blurStrength = 0.25; // Adjust this value to control the strength of the blur

vec3 rgbToHsl(vec3 color) {
    float cmin = min(min(color.r, color.g), color.b);
    float cmax = max(max(color.r, color.g), color.b);
    float delta = cmax - cmin;

    float hue = 0.0;
    if (delta == 0.0) {
        hue = 0.0;
    } else if (cmax == color.r) {
        hue = mod((color.g - color.b) / delta, 6.0);
    } else if (cmax == color.g) {
        hue = (color.b - color.r) / delta + 2.0;
    } else {
        hue = (color.r - color.g) / delta + 4.0;
    }
    hue /= 6.0;

    float lightness = 0.5 * (cmax + cmin);

    float saturation = 0.0;
    if (delta != 0.0) {
        saturation = delta / (1.0 - abs(2.0 * lightness - 1.0));
    }

    return vec3(hue, saturation, lightness);
}

vec3 hslToRgb(vec3 hsl) {
    float hue = hsl.x;
    float saturation = hsl.y;
    float lightness = hsl.z;

    float c = (1.0 - abs(2.0 * lightness - 1.0)) * saturation;
    float x = c * (1.0 - abs(mod(hue * 6.0, 2.0) - 1.0));
    float m = lightness - 0.5 * c;

    vec3 color = vec3(0.0);
    if (hue < 1.0/6.0) {
        color = vec3(c, x, 0.0);
    } else if (hue < 2.0/6.0) {
        color = vec3(x, c, 0.0);
    } else if (hue < 3.0/6.0) {
        color = vec3(0.0, c, x);
    } else if (hue < 4.0/6.0) {
        color = vec3(0.0, x, c);
    } else if (hue < 5.0/6.0) {
        color = vec3(x, 0.0, c);
    } else {
        color = vec3(c, 0.0, x);
    }

    return color + m;
}

void main()
{

    //downsampling
    vec2 resolution = vec2(854.0, 480.0);
    vec2 pixelSize = vec2(1.0) / resolution;
    vec2 samplePos = floor(texCoord / pixelSize) * pixelSize;

    vec2 samplePos00 = samplePos - vec2(blurSize * pixelSize.x, 0.0);
    vec2 samplePos10 = samplePos + vec2(blurSize * pixelSize.x, 0.0);
    vec2 samplePos01 = samplePos - vec2(0.0, blurSize * pixelSize.y);
    vec2 samplePos11 = samplePos + vec2(0.0, blurSize * pixelSize.y);

    vec3 texColor00 = texture(DiffuseSampler, samplePos00).rgb;
    vec3 texColor10 = texture(DiffuseSampler, samplePos10).rgb;
    vec3 texColor01 = texture(DiffuseSampler, samplePos01).rgb;
    vec3 texColor11 = texture(DiffuseSampler, samplePos11).rgb;

    vec3 color = (texColor00 + texColor10 + texColor01 + texColor11) / 4.0;

    // Bilateral filter
    vec3 blurredColor = vec3(0.0);
    float weightTotal = 0.0;
    float depthThreshold = 0.05; // Adjust this value to control the depth threshold
    float intensityThreshold = 0.1; // Adjust this value to control the intensity threshold
    for (float x = -blurSize; x <= blurSize; x += 1.0) {
        for (float y = -blurSize; y <= blurSize; y += 1.0) {
            vec2 offset = vec2(x, y) * pixelSize;
            vec3 sampleColor = texture(DiffuseSampler, texCoord + offset).rgb;
            vec3 diff = sampleColor - color;
            float distance = length(diff);
            float depthWeight = exp(-(distance * distance) / (2.0 * depthThreshold * depthThreshold));
            float intensityWeight = exp(-(dot(diff, diff) * 0.5) / (2.0 * intensityThreshold * intensityThreshold));
            float weight = depthWeight * intensityWeight;
            blurredColor += sampleColor * weight;
            weightTotal += weight;
        }
    }
    color = mix(color, blurredColor / weightTotal, blurStrength);

    // Convert RGB color to HSL
    vec3 hsl = rgbToHsl(color);

    // Adjust the luminance component
    float contrast = 1.5;
    hsl.z = (hsl.z - 0.5) * contrast + 0.5;

    // Convert HSL color back to RGB
    color.rgb = hslToRgb(hsl);

    // Boost the red and green channels to create a yellow tint
    float yellowTintStrength = 0.2;
    color.r += yellowTintStrength;
    color.g += yellowTintStrength * 0.5;

    // Lossy compression effect
    float compressionFactor = 20.0; // decrease to compress more
    color *= compressionFactor;
    color = round(color);
    color /= compressionFactor;

    fragColor = vec4(color, 1.0);
}