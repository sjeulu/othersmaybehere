#version 330

uniform sampler2D DiffuseSampler;
uniform float Time;

in vec2 texCoord;
in vec2 oneTexel;

out vec4 fragColor;

void main()
{
    float fisheye = 0.5;
    vec2 texCoordOffset = vec2(0.00075, 0.0);
    vec2 centeredTexCoord = 2.0 * texCoord - 1.0;
    float r = length(centeredTexCoord);
    vec2 distortedCoords = (centeredTexCoord * (0.9 + r * 0.1 * fisheye)) * 0.5 + 0.5;
    vec3 color = vec3(0.0);

    // add horizontal fuzz effect
    float fuzzStrength = 0.005;
    float fuzzFrequency = 10.0;
    float fuzzAmplitude = 0.003;
    float fuzzAmount = sin(Time * fuzzFrequency + fract(texCoord.y * fuzzFrequency) * 6.283185) * fuzzAmplitude;
    vec2 fuzzCoords = vec2(distortedCoords.x + fuzzAmount, distortedCoords.y);
    vec3 fuzzColor = vec3(0.0);
    fuzzColor.r = texture(DiffuseSampler, fuzzCoords + texCoordOffset).r;
    fuzzColor.g = texture(DiffuseSampler, fuzzCoords).g;
    fuzzColor.b = texture(DiffuseSampler, fuzzCoords - texCoordOffset).b;

    color = mix(color, fuzzColor, 0.3);

    // add green-blue blurred transverse chromatic aberration
    vec2 chromaticOffset = vec2(0.00075, 0.00075);
    color.r = texture(DiffuseSampler, distortedCoords).r;
    color.g = texture(DiffuseSampler, distortedCoords - chromaticOffset).g;
    color.b = texture(DiffuseSampler, distortedCoords + chromaticOffset).b;

    // add noise effect
    float noiseAmount = 0.01;
    float noise = fract(sin(dot(texCoord, vec2(12.9898, 78.233))) * 43758.5453);
    color += (noise - 0.5) * noiseAmount;

    // add vignette effect
    float vignetteAmount = 0.75;
    float vignetteSize = 1.0;
    float vignette = smoothstep(vignetteSize, 1.0, length(centeredTexCoord));
    color *= mix(1.0, vignetteAmount, vignette * vignette);

    fragColor = vec4(color, 1.0);
}